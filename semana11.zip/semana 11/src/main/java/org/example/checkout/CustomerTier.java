package org.example.checkout;

public enum CustomerTier {
    BASIC, SILVER, GOLD
}
