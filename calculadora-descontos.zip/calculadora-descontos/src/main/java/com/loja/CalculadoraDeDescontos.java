package com.loja;

public class CalculadoraDeDescontos {

    public double calcular(double valor) {
        validarValor(valor);
        if (valor < 100) return valor;
        if (valor <= 500) return aplicarDesconto(valor, 0.05);
        return aplicarDesconto(valor, 0.10);
    }

    private void validarValor(double valor) {
        if (valor < 0) {
            throw new IllegalArgumentException("Valor não pode ser negativo");
        }
    }

    private double aplicarDesconto(double valor, double percentual) {
        return valor - (valor * percentual);
    }
}
