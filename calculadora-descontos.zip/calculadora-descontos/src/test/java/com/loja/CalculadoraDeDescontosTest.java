package com.loja;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CalculadoraDeDescontosTest {

    @Test
    public void deveRetornarValorSemDescontoParaAbaixoDe100() {
        CalculadoraDeDescontos calc = new CalculadoraDeDescontos();
        assertEquals(80.0, calc.calcular(80.0));
    }

    @Test
    public void deveAplicar5PorCentoEntre100e500() {
        CalculadoraDeDescontos calc = new CalculadoraDeDescontos();
        assertEquals(190.0, calc.calcular(200.0));
    }

    @Test
    public void deveAplicar10PorCentoAcimaDe500() {
        CalculadoraDeDescontos calc = new CalculadoraDeDescontos();
        assertEquals(900.0, calc.calcular(1000.0));
    }

    @Test
    public void deveLancarIllegalArgumentExceptionParaValorNegativo() {
        CalculadoraDeDescontos calc = new CalculadoraDeDescontos();
        assertThrows(IllegalArgumentException.class,
                () -> calc.calcular(-10.0));
    }
}
